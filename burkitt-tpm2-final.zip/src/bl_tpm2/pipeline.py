"""End-to-end analysis: the single entry point of the project.

Usage (from the repository root):
    python run_analysis.py            # or: python -m bl_tpm2.pipeline (with src/ on PYTHONPATH)
    python run_analysis.py --refresh  # force a fresh download from cBioPortal
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from . import plots
from .cohort import build_cohort, describe_endpoint
from .data import DataUnavailableError, load_merged
from .evaluation import MODEL_SPECS, SEED, FoldPreprocessor, leave_one_center_out, repeated_cv
from .inference import interaction_test, tpm2_slope_test
from .logistic import GradientAscentLogisticRegression
from .reported_values import REPORTED
from .verification import all_passed, to_markdown, verify

ROOT = Path(__file__).resolve().parents[2]


def _fmt(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "—"
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    if abs(v) < 1e-3 and v != 0:
        return f"{v:.1e}"
    return f"{v:.3f}"


def comparison_rows(computed: dict, fold_mean: dict) -> list[dict]:
    rows = []
    for key, rep in REPORTED.items():
        comp = computed.get(key)
        row = {"quantity": key, "reported": rep, "reconstructed": comp, "fold_mean": fold_mean.get(key)}
        if comp is None:
            row["status"] = "not computed"
        elif key == "verify.max_abs_prob_diff":
            row["status"] = "consistent (both ≈ 0)" if comp < 1e-6 else "DIFFERS"
        elif isinstance(rep, int) and "auc" not in key:
            row["status"] = "match" if int(round(comp)) == rep else f"DIFFERS ({comp - rep:+.0f})"
        else:
            d = comp - rep
            row["status"] = "match (to reported precision)" if abs(d) <= 0.0015 else f"DIFFERS ({d:+.3f})"
        rows.append(row)
    return rows


def write_comparison(rows: list[dict], path: Path, notes: list[str]):
    lines = ["# Results vs. the written report", "",
             "Generated automatically by `bl_tpm2.pipeline`. *Reported* values are copied from the PDF "
             "report; *computed* values are recomputed from the live cBioPortal data on every run. "
             "Reported values are never used in any computation.", "",
             "AUC, balanced accuracy and log loss follow the report's protocol: metrics of the pooled "
             "out-of-fold predictions of each CV repeat, averaged over the 10 repeats. The last numeric "
             "column shows the alternative mean of the 50 per-fold AUCs for reference.", "",
             "| Quantity | Reported | Computed | Mean of fold AUCs | Status |", "|---|---:|---:|---:|---|"]
    for r in rows:
        lines.append(f"| `{r['quantity']}` | {_fmt(r['reported'])} | {_fmt(r['reconstructed'])} | "
                     f"{_fmt(r['fold_mean'])} | {r['status']} |")
    lines += ["", "## Notes", ""] + [f"- {n}" for n in notes]
    path.write_text("\n".join(lines) + "\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--refresh", action="store_true", help="re-download data from cBioPortal")
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=SEED, help=f"CV fold seed (default {SEED}, as in the report)")
    ap.add_argument("--out", type=Path, default=ROOT)
    args = ap.parse_args(argv)

    t0 = time.time()
    raw_dir, proc_dir = args.out / "data" / "raw", args.out / "data" / "processed"
    res_dir, fig_dir = args.out / "results", args.out / "figures"
    for d in (proc_dir, res_dir, fig_dir):
        d.mkdir(parents=True, exist_ok=True)

    # 1. Data, cohort, endpoint (report §3) ------------------------------------------------
    print("[1/9] Loading mbn_sfu_2023 from cBioPortal ...")
    try:
        merged = load_merged(raw_dir, force_download=args.refresh)
    except DataUnavailableError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    working, cohort = build_cohort(merged)
    # Patient-level files stay local (git-ignored); they are rebuilt from cBioPortal on every run.
    working.to_csv(proc_dir / "working_dataset.csv", index=False)
    cohort.to_csv(proc_dir / "patient_level_model_data.csv", index=False)
    ep = describe_endpoint(working, cohort)
    print(f"      Burkitt patients with TPM2: {ep['working_n']}; eligible: {ep['eligible_n']} "
          f"({ep['events']} events / {ep['non_events']} non-events); excluded: {ep['excluded_n']}")

    computed: dict = {f"cohort.{k}": v for k, v in ep.items()}
    fold_mean: dict = {}
    results: dict = {"endpoint": ep, "seed": args.seed, "repeats": args.repeats, "folds": args.folds}
    centre_counts = cohort.groupby("center")["progression_12m"].agg(n="size", events="sum").reset_index()
    centre_counts["event_rate"] = centre_counts["events"] / centre_counts["n"]
    centre_counts.to_csv(res_dir / "center_event_counts.csv", index=False)
    results["mean_age_by_outcome"] = {
        "events": float(cohort.loc[cohort.progression_12m == 1, "age"].mean()),
        "non_events": float(cohort.loc[cohort.progression_12m == 0, "age"].mean())}
    results["missing_values_in_cohort"] = {
        k: int(v) for k, v in cohort[["age", "age_category", "sex", "ebv_status", "hiv_status", "center"]]
        .isna().sum().items()}

    # 2. Optimiser on the full cohort + mathematical verification (report §§4-6) ---------------
    print("[2/9] Fitting gradient-ascent logistic regression and verifying the mathematics ...")
    pre = FoldPreprocessor(["tpm2_z"]).fit(cohort)
    x_std, y = pre.transform(cohort), cohort.progression_12m.to_numpy(int)
    full = GradientAscentLogisticRegression(record_history=True).fit(x_std, y)
    ver = verify(x_std, y, full)
    md = to_markdown(ver)
    (res_dir / "math_verification.md").write_text(md)
    results["math_verification"] = ver
    print(f"      all mathematical checks passed: {all_passed(md)}")

    # 3. In-sample tests (report §7) -----------------------------------------------------------
    print("[3/9] Wald and likelihood-ratio tests for the TPM2 slope ...")
    slope = tpm2_slope_test(cohort)
    results["tpm2_slope_test_raw_zscore"] = slope
    computed["tpm2.p_wald"], computed["tpm2.p_lrt"] = slope["p_wald"], slope["p_lrt"]

    # 4. Repeated stratified CV (report §§6-7) + comparison models -----------------------------
    print("[4/9] Repeated stratified 5-fold CV x10 (TPM2 + comparison models) ...")
    cv_results = {name: repeated_cv(cohort, feats, name, n_splits=args.folds,
                                    n_repeats=args.repeats, seed=args.seed)
                  for name, feats in MODEL_SPECS.items()}
    summary = pd.DataFrame([r.summary() for r in cv_results.values()])
    summary.to_csv(res_dir / "model_comparison.csv", index=False)
    tpm2 = cv_results["TPM2 only"]
    tpm2.per_repeat().to_csv(res_dir / "cross_validation_metrics.csv", index=False)
    tpm2.folds.to_csv(res_dir / "handcoded_vs_sklearn.csv", index=False)
    pd.concat([r.folds.assign(model=n) for n, r in cv_results.items()]).to_csv(
        res_dir / "cv_folds_all_models.csv", index=False)
    print(summary[["model", "auc_mean", "balanced_accuracy_mean", "log_loss_mean", "brier_mean",
                   "sklearn_max_abs_prob_diff"]].to_string(index=False))
    tp = summary.set_index("model").loc["TPM2 only"]
    computed.update({"tpm2.auc": tp.auc_mean, "tpm2.balanced_accuracy": tp.balanced_accuracy_mean,
                     "tpm2.log_loss": tp.log_loss_mean,
                     "baseline.balanced_accuracy": tp.baseline_balanced_accuracy_mean,
                     "baseline.log_loss": tp.baseline_log_loss_mean,
                     "verify.max_abs_prob_diff": float(tpm2.sklearn_max_abs_diff)})
    fold_mean["tpm2.auc"] = tp.fold_auc_mean
    per_rep = tpm2.per_repeat()
    computed["tpm2.roc_repeat1_pooled_auc"] = float(per_rep.query("repeat == 1 and model == 'TPM2 only'").auc.iloc[0])
    results["models"] = summary.to_dict(orient="records")

    # 5. Subgroups + interactions (report §9) ---------------------------------------------------
    print("[5/9] Subgroup analyses and interaction tests ...")
    sub_rows = []
    for col, level in [("ebv_status", "EBV-positive"), ("ebv_status", "EBV-negative"),
                       ("age_category", "Pediatric"), ("age_category", "Adult")]:
        d = cohort[cohort[col] == level].reset_index(drop=True)
        r = repeated_cv(d, ["tpm2_z"], level, n_splits=args.folds, n_repeats=args.repeats,
                        seed=args.seed, verify_sklearn=False).summary()
        sub_rows.append({"subgroup": level, "n": r["n"], "events": r["events"], "auc_mean": r["auc_mean"],
                         "auc_sd": r["auc_sd"], "fold_auc_mean": r["fold_auc_mean"],
                         "balanced_accuracy_mean": r["balanced_accuracy_mean"],
                         "log_loss_mean": r["log_loss_mean"],
                         "reported_auc": REPORTED.get(f"subgroup.{level}.auc")})
        computed[f"subgroup.{level}.n"], computed[f"subgroup.{level}.events"] = r["n"], r["events"]
        computed[f"subgroup.{level}.auc"] = r["auc_mean"]
        fold_mean[f"subgroup.{level}.auc"] = r["fold_auc_mean"]
    computed["subgroup.age_unknown.n"] = int(cohort.age_category.isna().sum())
    subgroups = pd.DataFrame(sub_rows)
    subgroups.to_csv(res_dir / "subgroups.csv", index=False)
    inter_ebv = interaction_test(cohort, "ebv_status", "EBV-positive")
    inter_age = interaction_test(cohort, "age_category", "Adult")
    computed["interaction.ebv.p"] = inter_ebv["p_lrt"]               # LRT, 1 df
    computed["interaction.age_category.p"] = inter_age["p_lrt"]
    results["subgroups"] = sub_rows
    results["interaction_tests"] = {"ebv": inter_ebv, "age_category": inter_age}
    print(subgroups[["subgroup", "n", "events", "auc_mean"]].to_string(index=False))

    # 6. Leave-one-centre-out (extension) -------------------------------------------------------
    print("[6/9] Leave-one-centre-out validation ...")
    loco = {name: leave_one_center_out(cohort, feats) for name, feats in MODEL_SPECS.items()}
    pd.concat([t.assign(model=n) for n, (t, _) in loco.items()]).to_csv(
        res_dir / "leave_one_center_out.csv", index=False)
    results["leave_one_center_out"] = {n: s for n, (_, s) in loco.items()}

    # 7. Figures ----------------------------------------------------------------------------------
    print("[7/9] Drawing figures ...")
    results["alpha_sweep_final_mean_loglik"] = plots.gradient_convergence(x_std, y, fig_dir)
    plots.tpm2_distribution(cohort, fig_dir)
    plots.roc_single_repeat(tpm2, fig_dir)
    plots.descriptive_fit(cohort, full.beta_, pre.mean_["tpm2_z"], pre.sd_["tpm2_z"], fig_dir)
    plots.heldout_predictions(tpm2, fig_dir)
    plots.roc_all_models(cv_results, fig_dir)
    plots.model_comparison(cv_results, REPORTED, fig_dir)
    plots.metric_panel(summary, fig_dir)
    plots.subgroup_chart(subgroups, fig_dir)
    plots.center_chart(loco, centre_counts, fig_dir)
    plots.sklearn_agreement({n: r.sklearn_max_abs_diff for n, r in cv_results.items()}, fig_dir)

    # 8. Comparison with the report -----------------------------------------------------------
    print("[8/9] Comparing with the written report ...")
    rows = comparison_rows(computed, fold_mean)
    notes = [
        f"Endpoint: y=1 if PFS_STATUS='1:Progression' and PFS_MONTHS ≤ 12; y=0 if PFS_MONTHS ≥ 12 without "
        f"progression by month 12. {ep['non_events_with_progression_after_12m']} of the y=0 patients progressed "
        f"after month 12. Excluded: {ep['excluded_missing_pfs']} with missing PFS data, "
        f"{ep['excluded_censored_before_12m']} censored before 12 months.",
        f"CV: RepeatedStratifiedKFold(n_splits={args.folds}, n_repeats={args.repeats}, random_state={args.seed}); "
        "TPM2 standardised within training folds.",
        "Interaction p-values are likelihood-ratio tests (1 df) of the TPM2×group product term; Wald p-values "
        f"(EBV {inter_ebv['p_wald']:.3f}, age category {inter_age['p_wald']:.3f}) are in results.json.",
        f"Direction: TPM2 slope {slope['coef']:+.3f} per z-score unit (OR {slope['odds_ratio']:.2f}, 95% CI "
        f"{slope['or_ci95'][0]:.2f}–{slope['or_ci95'][1]:.2f}): higher TPM2 went with lower recorded 12-month "
        "progression in this cohort. The report does not state the direction.",
        f"Report Figure 1: converged mean log-likelihood {full.log_likelihood_ / len(y):.4f}; after 3000 fixed steps "
        "the α-sweep reaches " + ", ".join(f"α={a:g}: {v:.4f}" for a, v in results["alpha_sweep_final_mean_loglik"].items())
        + " (see fig01).",
        "Comparison models (age, clinical, combined) and leave-one-centre-out are extensions: the updated report gives "
        "no numbers for them. Pooled LOCO AUCs: " + "; ".join(f"{n} {s['pooled_auc']:.3f}" for n, (_, s) in loco.items()) + ".",
    ]
    write_comparison(rows, res_dir / "comparison_to_report.md", notes)
    results["comparison_to_report"] = rows
    (res_dir / "results.json").write_text(json.dumps(results, indent=2, default=lambda o: o.item()
                                                     if hasattr(o, "item") else str(o)))
    n_diff = sum(r["status"].startswith("DIFFERS") for r in rows)
    print(f"[9/9] Done in {time.time() - t0:.0f}s. {len(rows) - n_diff}/{len(rows)} reported quantities match; "
          f"{n_diff} differ. Math checks passed: {all_passed(md)}. See results/.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
