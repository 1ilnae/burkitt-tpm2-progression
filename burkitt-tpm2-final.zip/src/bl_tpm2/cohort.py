"""Cohort selection and 12-month progression endpoint (report Section 3).

Rules, written from the report:

* Working dataset: Burkitt lymphoma patients (CANCER_TYPE_DETAILED == "Burkitt Lymphoma")
  with a measured TPM2 z-score.
* y = 1  if a progression event is recorded (PFS_STATUS = "1:Progression") at
         PFS_MONTHS <= 12.
* y = 0  if the patient was observed for at least 12 months (PFS_MONTHS >= 12)
         without a progression event in that window.
* Otherwise (missing PFS data, or censored before 12 months) the patient cannot
  be given a defensible 12-month label and is EXCLUDED.

Interpretation note: patients whose first progression was recorded *after*
month 12 are progression-free at 12 months and are labelled y = 0 here. The
report's wording ("no event was recorded") could be read more strictly; the
pipeline reports how many patients fall in this category so the choice is
transparent (see ``describe_endpoint``).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

HORIZON_MONTHS = 12.0


def build_endpoint(pfs_months: pd.Series, pfs_status: pd.Series,
                   horizon: float = HORIZON_MONTHS) -> pd.Series:
    """Return a float Series: 1.0, 0.0 or NaN (= not assignable / excluded)."""
    months = pd.to_numeric(pfs_months, errors="coerce")
    status = pfs_status.astype("string")
    event = status.str.startswith("1").fillna(False).astype(bool)
    known = months.notna() & status.notna()

    y = pd.Series(np.nan, index=months.index, dtype=float)
    y[known & event & (months <= horizon)] = 1.0
    y[known & (months >= horizon) & ~(event & (months <= horizon))] = 0.0
    return y


def build_cohort(merged: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (working_dataset, eligible_cohort) with tidy analysis columns."""
    bl = merged[(merged["CANCER_TYPE_DETAILED"] == "Burkitt Lymphoma") & merged["tpm2_z"].notna()].copy()
    if bl["patientId"].duplicated().any():
        # One sample per patient is expected in this study; keep the first if not.
        bl = bl.drop_duplicates("patientId", keep="first")

    tidy = pd.DataFrame({
        "patient_id": bl["patientId"].values,
        "sample_id": bl["sampleId"].values,
        "tpm2_z": bl["tpm2_z"].astype(float).values,
        "age": pd.to_numeric(bl.get("AGE"), errors="coerce").values,
        "age_category": bl.get("AGE_CATEGORY").values,
        "sex": bl.get("SEX").values,
        "ebv_status": bl.get("EBV_GENOME_STATUS").values,
        "hiv_status": bl.get("HIV_STATUS").values,
        "center": bl.get("SOURCE").values,
        "pfs_months": pd.to_numeric(bl.get("PFS_MONTHS"), errors="coerce").values,
        "pfs_status": bl.get("PFS_STATUS").values,
        "subgroup": bl.get("PATIENT_SUBGROUP").values,
    })
    tidy["progression_12m"] = build_endpoint(tidy["pfs_months"], tidy["pfs_status"]).values
    eligible = tidy[tidy["progression_12m"].notna()].copy()
    eligible["progression_12m"] = eligible["progression_12m"].astype(int)
    return tidy.reset_index(drop=True), eligible.reset_index(drop=True)


def describe_endpoint(working: pd.DataFrame, eligible: pd.DataFrame) -> dict:
    months = working["pfs_months"]
    status = working["pfs_status"].astype("string")
    excluded = working[working["progression_12m"].isna()]
    late_events = eligible[(eligible["progression_12m"] == 0)
                           & eligible["pfs_status"].astype(str).str.startswith("1")]
    return {
        "working_n": int(len(working)),
        "eligible_n": int(len(eligible)),
        "events": int(eligible["progression_12m"].sum()),
        "non_events": int((eligible["progression_12m"] == 0).sum()),
        "excluded_n": int(len(excluded)),
        "excluded_missing_pfs": int((excluded["pfs_months"].isna() | excluded["pfs_status"].isna()).sum()),
        "excluded_censored_before_12m": int((excluded["pfs_months"].notna() & excluded["pfs_status"].notna()).sum()),
        "non_events_with_progression_after_12m": int(len(late_events)),
        "working_missing_pfs_months": int(months.isna().sum()),
        "working_missing_pfs_status": int(status.isna().sum()),
    }
