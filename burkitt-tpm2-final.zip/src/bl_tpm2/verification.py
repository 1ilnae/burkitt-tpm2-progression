"""Numerical verification of the optimiser on the real analysis cohort.

Checks, each computed at run time and written to results/math_verification.md:

1. Sigmoid: sigma(0) = 1/2, sigma(z) + sigma(-z) = 1, finite for |z| up to 1000.
2. Log-likelihood: the stable form sum[y z - log(1+e^z)] equals the textbook
   Bernoulli form sum[y log p + (1-y) log(1-p)].
3. Gradient: the analytical X^T(y - p) matches central finite differences of l(beta).
4. Concavity: the Hessian -X^T W X is negative definite (all eigenvalues < 0), so
   the maximiser is unique and any convergent ascent finds the same optimum.
5. Update rule: one step equals beta + alpha * X^T(y - p)/n exactly.
6. Convergence: final ||grad||_inf, monotone log-likelihood, and agreement with
   (a) an independent Newton-Raphson solver written here, (b) scikit-learn, and
   (c) the original script's fixed schedule (alpha = 0.2, 5000 steps).
"""
from __future__ import annotations

import warnings

import numpy as np

from .evaluation import sklearn_unpenalised
from .logistic import (GradientAscentLogisticRegression, add_intercept, gradient, hessian,
                       log_likelihood, sigmoid)


def newton_raphson(design, y, tol=1e-12, max_iter=100):
    """Independent second solver: beta <- beta - H^{-1} grad."""
    beta = np.zeros(design.shape[1])
    for _ in range(max_iter):
        step = np.linalg.solve(hessian(beta, design), gradient(beta, design, y))
        beta = beta - step
        if np.max(np.abs(step)) < tol:
            break
    return beta


def verify(x_std: np.ndarray, y: np.ndarray, fitted: GradientAscentLogisticRegression) -> dict:
    y = np.asarray(y, dtype=float)
    D = add_intercept(x_std)
    n = len(y)
    out: dict = {}

    z = np.array([-1000.0, -30.0, -1.0, 0.0, 1.0, 30.0, 1000.0])
    s = sigmoid(z)
    out["sigmoid_half_at_zero"] = bool(sigmoid(np.array([0.0]))[0] == 0.5)
    out["sigmoid_symmetry_max_err"] = float(np.max(np.abs(s + sigmoid(-z) - 1)))
    out["sigmoid_finite"] = bool(np.all(np.isfinite(s)))

    rng = np.random.default_rng(0)
    beta_r = rng.normal(scale=0.5, size=D.shape[1])
    p = sigmoid(D @ beta_r)
    textbook = float(np.sum(y * np.log(p) + (1 - y) * np.log(1 - p)))
    out["loglik_forms_abs_diff"] = abs(textbook - log_likelihood(beta_r, D, y))

    eps = 1e-6
    for label, b in (("random_beta", beta_r), ("fitted_beta", fitted.beta_)):
        num = np.array([(log_likelihood(b + eps * e, D, y) - log_likelihood(b - eps * e, D, y)) / (2 * eps)
                        for e in np.eye(len(b))])
        out[f"gradient_vs_finite_diff_max_abs_err[{label}]"] = float(np.max(np.abs(num - gradient(b, D, y))))

    eig = np.linalg.eigvalsh(hessian(fitted.beta_, D))
    out["hessian_eigenvalues_at_optimum"] = eig.tolist()
    out["strictly_concave"] = bool(np.all(eig < 0))

    alpha = 0.2
    one = GradientAscentLogisticRegression(learning_rate=alpha, max_iter=1)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        one.fit(x_std, y)
    manual = alpha * D.T @ (y - 0.5) / n
    out["one_step_update_max_abs_err"] = float(np.max(np.abs(one.beta_ - manual)))

    out["converged"] = bool(fitted.converged_)
    out["monotone_ascent"] = bool(fitted.monotone_)
    out["iterations"] = int(fitted.n_iter_)
    out["final_mean_grad_inf_norm"] = float(fitted.final_grad_inf_norm_)
    out["mean_loglik_at_optimum"] = float(fitted.log_likelihood_ / n)

    nr = newton_raphson(D, y)
    sk = sklearn_unpenalised().fit(x_std, y)
    sk_beta = np.r_[sk.intercept_, sk.coef_.ravel()]
    legacy = GradientAscentLogisticRegression(learning_rate=0.2, max_iter=5000, tol=0.0)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        legacy.fit(x_std, y)
    out["beta_gradient_ascent"] = fitted.beta_.tolist()
    out["beta_max_abs_diff_vs_newton_raphson"] = float(np.max(np.abs(fitted.beta_ - nr)))
    out["beta_max_abs_diff_vs_sklearn"] = float(np.max(np.abs(fitted.beta_ - sk_beta)))
    out["beta_max_abs_diff_vs_alpha0.2_5000_steps"] = float(np.max(np.abs(fitted.beta_ - legacy.beta_)))
    return out


def to_markdown(v: dict) -> str:
    def ok(cond):
        return "✅ pass" if cond else "❌ FAIL"

    rows = [
        ("Sigmoid: σ(0) = 0.5", v["sigmoid_half_at_zero"], "exact"),
        ("Sigmoid: σ(z) + σ(−z) = 1", v["sigmoid_symmetry_max_err"] < 1e-12, f"{v['sigmoid_symmetry_max_err']:.1e}"),
        ("Sigmoid finite for z in [−1000, 1000]", v["sigmoid_finite"], "—"),
        ("Bernoulli log-likelihood: stable form = textbook form", v["loglik_forms_abs_diff"] < 1e-8,
         f"{v['loglik_forms_abs_diff']:.1e}"),
    ]
    for k, val in v.items():
        if k.startswith("gradient_vs_finite_diff"):
            rows.append((f"Analytical gradient = finite differences ({k.split('[')[1][:-1].replace('_', ' ')})",
                         val < 1e-5, f"{val:.1e}"))
    rows += [
        ("Hessian negative definite (unique optimum)", v["strictly_concave"],
         ", ".join(f"{e:.2f}" for e in v["hessian_eigenvalues_at_optimum"])),
        ("One update = β + α·Xᵀ(y−p)/n (α = 0.2)", v["one_step_update_max_abs_err"] < 1e-15,
         f"{v['one_step_update_max_abs_err']:.1e}"),
        ("Converged (‖g‖∞ < 1e-9)", v["converged"], f"{v['final_mean_grad_inf_norm']:.1e} after {v['iterations']} it."),
        ("Log-likelihood never decreased", v["monotone_ascent"], "—"),
        ("β equals independent Newton–Raphson solution", v["beta_max_abs_diff_vs_newton_raphson"] < 1e-7,
         f"{v['beta_max_abs_diff_vs_newton_raphson']:.1e}"),
        ("β equals scikit-learn (unpenalised)", v["beta_max_abs_diff_vs_sklearn"] < 1e-6,
         f"{v['beta_max_abs_diff_vs_sklearn']:.1e}"),
        ("β equals original schedule (α = 0.2, 5000 steps)", v["beta_max_abs_diff_vs_alpha0.2_5000_steps"] < 1e-6,
         f"{v['beta_max_abs_diff_vs_alpha0.2_5000_steps']:.1e}"),
    ]
    lines = ["# Mathematical verification (TPM2-only model, full analysis cohort)", "",
             "Generated by `bl_tpm2.verification` on every run. TPM2 is standardised over the cohort. "
             f"Fitted β = ({v['beta_gradient_ascent'][0]:.6f}, {v['beta_gradient_ascent'][1]:.6f}); "
             f"mean log-likelihood at the optimum = {v['mean_loglik_at_optimum']:.6f}.", "",
             "| Check | Result | Value |", "|---|---|---|"]
    lines += [f"| {name} | {ok(c)} | {val} |" for name, c, val in rows]
    return "\n".join(lines) + "\n"


def all_passed(md: str) -> bool:
    return "FAIL" not in md
