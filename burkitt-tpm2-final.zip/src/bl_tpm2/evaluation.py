"""Patient-level validation (report Sections 6, 7 and 9).

Protocol (identical to the original TPM2-only analysis script that produced the
report's numbers):

* Repeated stratified 5-fold CV, 10 repeats, ``random_state = 20261115``.
* Preprocessing (median / mode imputation, standardisation, reference-coded
  indicators) is fitted on the four training folds only.
* Each repeat yields exactly one out-of-fold (held-out) probability per patient.
  Metrics - ROC-AUC, balanced accuracy (threshold 0.5), log loss, Brier score -
  are computed on those pooled out-of-fold predictions for each repeat, then
  averaged over the 10 repeats. This is the "mean out-of-fold ROC-AUC" in the
  report.
* Prevalence-only baseline: every held-out patient receives the training-fold
  event rate.
* The mean of the 50 per-fold AUCs is also stored as a secondary summary.
* Leave-one-centre-out evaluation for cross-hospital generalisation (extension).
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, brier_score_loss, log_loss, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold

from .logistic import GradientAscentLogisticRegression

SEED = 20261115            # fold seed used by the original analysis
NUMERIC = {"tpm2_z", "age"}
CLINICAL = ["age", "sex", "ebv_status", "hiv_status"]
MODEL_SPECS = {
    "TPM2 only": ["tpm2_z"],
    "Age only": ["age"],
    "Clinical (age, sex, EBV, HIV)": CLINICAL,
    "TPM2 + clinical": ["tpm2_z"] + CLINICAL,
}
THRESHOLD = 0.5


class FoldPreprocessor:
    """Imputation + scaling + indicator coding learned from training rows only."""

    def __init__(self, features: list[str]):
        self.features = features

    def fit(self, df: pd.DataFrame):
        self.num_ = [c for c in self.features if c in NUMERIC]
        self.cat_ = [c for c in self.features if c not in NUMERIC]
        self.median_, self.mean_, self.sd_ = {}, {}, {}
        for c in self.num_:
            col = df[c].astype(float)
            self.median_[c] = col.median()
            filled = col.fillna(self.median_[c])
            self.mean_[c] = filled.mean()
            self.sd_[c] = filled.std(ddof=0) or 1.0
        self.mode_, self.levels_ = {}, {}
        for c in self.cat_:
            col = df[c]
            self.mode_[c] = col.mode(dropna=True).iloc[0]
            levels = sorted(col.fillna(self.mode_[c]).unique())
            self.levels_[c] = levels[1:]        # first level = reference category
        return self

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        cols = []
        for c in self.num_:
            v = df[c].astype(float).fillna(self.median_[c])
            cols.append(((v - self.mean_[c]) / self.sd_[c]).to_numpy())
        for c in self.cat_:
            v = df[c].fillna(self.mode_[c])
            cols.extend((v == lvl).astype(float).to_numpy() for lvl in self.levels_[c])
        return np.column_stack(cols) if cols else np.empty((len(df), 0))

    def feature_names(self) -> list[str]:
        return list(self.num_) + [f"{c}={lvl}" for c in self.cat_ for lvl in self.levels_[c]]


def metrics(y_true, prob) -> dict:
    """ROC-AUC (NaN if one class only), balanced accuracy, log loss, Brier score."""
    y_true = np.asarray(y_true)
    prob = np.asarray(prob, dtype=float)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return {
            "auc": roc_auc_score(y_true, prob) if len(np.unique(y_true)) == 2 else np.nan,
            "balanced_accuracy": balanced_accuracy_score(y_true, prob >= THRESHOLD),
            "log_loss": log_loss(y_true, np.clip(prob, 1e-15, 1 - 1e-15), labels=[0, 1]),
            "brier": brier_score_loss(y_true, prob),
        }


@dataclass
class CVResult:
    name: str
    folds: pd.DataFrame            # one row per (repeat, fold): fold-level metrics + coefficients
    oof: np.ndarray                # (n_repeats, n) out-of-fold model probabilities
    base_oof: np.ndarray           # (n_repeats, n) out-of-fold prevalence-baseline probabilities
    y: np.ndarray
    sklearn_max_abs_diff: float = np.nan
    non_converged_fits: int = 0

    def per_repeat(self) -> pd.DataFrame:
        """Pooled out-of-fold metrics for each repeat (model and baseline)."""
        rows = []
        for r in range(self.oof.shape[0]):
            for kind, p in ((self.name, self.oof[r]), ("Prevalence-only baseline", self.base_oof[r])):
                rows.append({"repeat": r + 1, "model": kind, **metrics(self.y, p)})
        return pd.DataFrame(rows)

    def summary(self) -> dict:
        pr = self.per_repeat()
        m, b = pr[pr.model == self.name], pr[pr.model != self.name]
        return {
            "model": self.name, "n": int(len(self.y)), "events": int(self.y.sum()),
            "auc_mean": float(m.auc.mean()), "auc_sd": float(m.auc.std(ddof=1)),
            "balanced_accuracy_mean": float(m.balanced_accuracy.mean()),
            "log_loss_mean": float(m.log_loss.mean()), "brier_mean": float(m.brier.mean()),
            "baseline_auc_mean": float(b.auc.mean()),
            "baseline_balanced_accuracy_mean": float(b.balanced_accuracy.mean()),
            "baseline_log_loss_mean": float(b.log_loss.mean()), "baseline_brier_mean": float(b.brier.mean()),
            "fold_auc_mean": float(self.folds.auc.mean()), "fold_auc_sd": float(self.folds.auc.std(ddof=1)),
            "sklearn_max_abs_prob_diff": float(self.sklearn_max_abs_diff),
            "non_converged_fits": int(self.non_converged_fits),
        }


def sklearn_unpenalised():
    """scikit-learn logistic regression with the SAME objective (no penalty)."""
    return LogisticRegression(C=np.inf, solver="lbfgs", tol=1e-12, max_iter=100_000)


def repeated_cv(df: pd.DataFrame, features: list[str], name: str, n_splits: int = 5,
                n_repeats: int = 10, seed: int = SEED, verify_sklearn: bool = True) -> CVResult:
    y = df["progression_12m"].to_numpy(int)
    cv = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=seed)
    oof = np.full((n_repeats, len(y)), np.nan)
    base_oof = np.full((n_repeats, len(y)), np.nan)
    rows, max_diff, non_conv = [], 0.0, 0
    for k, (tr, te) in enumerate(cv.split(np.zeros(len(y)), y)):
        r, fold = divmod(k, n_splits)
        pre = FoldPreprocessor(features).fit(df.iloc[tr])
        Xtr, Xte = pre.transform(df.iloc[tr]), pre.transform(df.iloc[te])
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            model = GradientAscentLogisticRegression().fit(Xtr, y[tr])
        non_conv += int(not model.converged_)
        prob = model.predict_proba(Xte)[:, 1]
        oof[r, te] = prob
        base_oof[r, te] = y[tr].mean()
        row = {"repeat": r + 1, "fold": fold + 1, "n_test": len(te), **metrics(y[te], prob),
               "n_iter": model.n_iter_, "intercept_own": model.intercept_}
        names = pre.feature_names()
        row.update({f"coef_own[{n}]": c for n, c in zip(names, model.coef_)})
        if verify_sklearn:
            sk = sklearn_unpenalised().fit(Xtr, y[tr])
            diff = float(np.max(np.abs(sk.predict_proba(Xte)[:, 1] - prob)))
            max_diff = max(max_diff, diff)
            row["intercept_sklearn"] = float(sk.intercept_[0])
            row.update({f"coef_sklearn[{n}]": c for n, c in zip(names, sk.coef_.ravel())})
            row["max_abs_prob_difference"] = diff
        rows.append(row)
    return CVResult(name, pd.DataFrame(rows), oof, base_oof, y,
                    sklearn_max_abs_diff=max_diff if verify_sklearn else np.nan,
                    non_converged_fits=non_conv)


def leave_one_center_out(df: pd.DataFrame, features: list[str]) -> tuple[pd.DataFrame, dict]:
    """Train on all other centres, evaluate on the withheld centre."""
    d = df[df["center"].notna()].reset_index(drop=True)
    y = d["progression_12m"].to_numpy(int)
    pooled = np.full(len(y), np.nan)
    rows = []
    for center, idx in d.groupby("center").indices.items():
        tr = np.setdiff1d(np.arange(len(d)), idx)
        pre = FoldPreprocessor(features).fit(d.iloc[tr])
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            model = GradientAscentLogisticRegression().fit(pre.transform(d.iloc[tr]), y[tr])
        prob = model.predict_proba(pre.transform(d.iloc[idx]))[:, 1]
        pooled[idx] = prob
        rows.append({"center": center, "n": len(idx), "events": int(y[idx].sum()),
                     "event_rate": float(y[idx].mean()), **metrics(y[idx], prob),
                     "train_event_rate": float(y[tr].mean())})
    table = pd.DataFrame(rows).sort_values("n", ascending=False).reset_index(drop=True)
    ok = ~np.isnan(pooled)
    summary = {
        "pooled_auc": float(roc_auc_score(y[ok], pooled[ok])),
        "mean_within_center_auc": float(table["auc"].mean(skipna=True)),
        "centers_evaluated": int(len(table)),
        "centers_with_auc": int(table["auc"].notna().sum()),
        "patients_without_center": int(df["center"].isna().sum()),
    }
    return table, summary
