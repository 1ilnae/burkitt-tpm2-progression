"""Logistic regression implemented from scratch with NumPy (report Sections 4-5).

Model
    z_i = beta_0 + beta^T x_i,     p_i = sigma(z_i) = 1 / (1 + exp(-z_i))

Bernoulli log-likelihood
    l(beta) = sum_i [ y_i log p_i + (1 - y_i) log(1 - p_i) ]
            = sum_i [ y_i z_i - log(1 + exp(z_i)) ]          (numerically stable form)

Analytical gradient
    grad l(beta) = X^T (y - p)        (X includes a leading column of ones)

Gradient ascent (on the MEAN log-likelihood, as in the report)
    g = X^T (y - p) / n,      beta <- beta + alpha * g,      starting from beta = 0

Step size. The mean log-likelihood has Hessian -X^T W X / n with W = diag(p(1-p))
<= 1/4, so its gradient is L-Lipschitz with L = lambda_max(X^T X / n) / 4.
Any fixed alpha in (0, 2/L) converges; alpha = 1/L (the default when
``learning_rate=None``) guarantees a monotone increase of l(beta). A user-supplied
fixed alpha (e.g. 0.2 from the worked example) is also supported.

Convergence checks
    * gradient criterion: ||g||_inf < tol
    * monotonicity: l(beta) must never decrease (flagged if it does)
    * iteration cap: ``converged_`` is False if max_iter is hit (e.g. under
      complete separation, where the unpenalised MLE does not exist)
"""
from __future__ import annotations

import warnings

import numpy as np


def sigmoid(z):
    """Numerically stable logistic function 1 / (1 + e^{-z})."""
    z = np.asarray(z, dtype=float)
    out = np.empty_like(z)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1.0 + ez)
    return out


def add_intercept(X) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    return np.column_stack([np.ones(X.shape[0]), X])


def log_likelihood(beta, design, y) -> float:
    """Bernoulli log-likelihood (sum over patients). ``design`` includes the intercept column."""
    z = design @ beta
    return float(np.sum(y * z - np.logaddexp(0.0, z)))


def gradient(beta, design, y) -> np.ndarray:
    """Analytical gradient X^T (y - p) of the summed log-likelihood."""
    return design.T @ (y - sigmoid(design @ beta))


def hessian(beta, design) -> np.ndarray:
    """Hessian of the summed log-likelihood: -X^T W X, W = diag(p (1 - p))."""
    p = sigmoid(design @ beta)
    return -(design.T * (p * (1.0 - p))) @ design


class GradientAscentLogisticRegression:
    """Unpenalised logistic regression fitted by plain (full-batch) gradient ascent."""

    def __init__(self, learning_rate: float | None = None, max_iter: int = 500_000,
                 tol: float = 1e-9, record_history: bool = False):
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.tol = tol
        self.record_history = record_history

    # -- fitting ---------------------------------------------------------------
    def fit(self, X, y):
        y = np.asarray(y, dtype=float).ravel()
        design = add_intercept(X)
        n = design.shape[0]
        if n == 0 or n != len(y):
            raise ValueError("X and y must be non-empty with matching rows")
        if not (np.all(np.isfinite(design)) and np.all(np.isfinite(y))):
            raise ValueError("Features and labels must be finite (impute before fitting)")
        if not np.all(np.isin(y, (0.0, 1.0))):
            raise ValueError("y must contain only 0/1")

        if self.learning_rate is None:
            lipschitz = np.linalg.eigvalsh(design.T @ design / n).max() / 4.0
            alpha = 1.0 / lipschitz
        else:
            alpha = float(self.learning_rate)
        self.learning_rate_ = alpha

        beta = np.zeros(design.shape[1])
        ll = log_likelihood(beta, design, y)
        history = [ll] if self.record_history else None
        monotone = True
        converged = False
        it = 0
        for it in range(1, self.max_iter + 1):
            g = gradient(beta, design, y) / n          # mean-log-likelihood gradient
            if np.max(np.abs(g)) < self.tol:
                converged = True
                it -= 1
                break
            beta = beta + alpha * g
            ll_new = log_likelihood(beta, design, y)
            if ll_new < ll - 1e-12 * max(1.0, abs(ll)):
                monotone = False
            ll = ll_new
            if history is not None:
                history.append(ll)

        self.beta_ = beta
        self.intercept_ = float(beta[0])
        self.coef_ = beta[1:].copy()
        self.n_iter_ = it
        self.converged_ = converged
        self.monotone_ = monotone
        self.log_likelihood_ = ll
        self.final_grad_inf_norm_ = float(np.max(np.abs(gradient(beta, design, y) / n)))
        self.history_ = np.array(history) if history is not None else None
        if not converged:
            warnings.warn(f"Gradient ascent did not converge in {self.max_iter} iterations "
                          f"(||g||_inf={self.final_grad_inf_norm_:.2e}); possible separation.",
                          RuntimeWarning, stacklevel=2)
        return self

    # -- prediction ------------------------------------------------------------
    def decision_function(self, X):
        if not hasattr(self, "beta_"):
            raise ValueError("Model is not fitted")
        return add_intercept(X) @ self.beta_

    def predict_proba(self, X):
        p = sigmoid(self.decision_function(X))
        return np.column_stack([1.0 - p, p])

    def predict(self, X, threshold: float = 0.5):
        return (self.predict_proba(X)[:, 1] >= threshold).astype(int)

    # -- inference (in-sample, Section 7) ----------------------------------------
    def standard_errors(self, X) -> np.ndarray:
        """Wald standard errors from the observed information matrix (-Hessian)^-1."""
        info = -hessian(self.beta_, add_intercept(X))
        return np.sqrt(np.diag(np.linalg.inv(info)))
