"""In-sample inferential tests built on the custom optimiser (report Sections 7 and 9).

* Wald test for a single coefficient:   z = beta_j / SE_j,  p = 2 * (1 - Phi(|z|))
* Likelihood-ratio test of nested models: LR = 2 (l_full - l_reduced) ~ chi2(df)
* Interaction tests: TPM2 x EBV status and TPM2 x age category, each fitted as
      logit p = b0 + b1*TPM2 + b2*G + b3*(TPM2*G)
  and tested on b3 (Wald and LRT against the model without the product term).

These tests describe the fitted sample; they are not measures of out-of-sample
predictive usefulness.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

from .logistic import GradientAscentLogisticRegression, add_intercept, log_likelihood


def _fit(X, y):
    return GradientAscentLogisticRegression(tol=1e-10).fit(X, y)


def intercept_only_loglik(y) -> float:
    y = np.asarray(y, dtype=float)
    p = y.mean()
    return float(np.sum(y * np.log(p) + (1 - y) * np.log(1 - p)))


def wald_and_lrt(X_full, y, test_index: int, X_reduced=None) -> dict:
    """Fit the full model; Wald-test column ``test_index`` (0-based, excluding intercept)
    and LRT against ``X_reduced`` (intercept-only when None)."""
    y = np.asarray(y, dtype=float)
    full = _fit(X_full, y)
    se = full.standard_errors(X_full)
    j = test_index + 1
    beta, s = full.beta_[j], se[j]
    z = beta / s
    p_wald = 2 * stats.norm.sf(abs(z))
    if X_reduced is None:
        ll_red, df = intercept_only_loglik(y), add_intercept(X_full).shape[1] - 1
    else:
        red = _fit(X_reduced, y)
        ll_red = red.log_likelihood_
        df = add_intercept(X_full).shape[1] - add_intercept(X_reduced).shape[1]
    lr = 2 * (full.log_likelihood_ - ll_red)
    return {
        "coef": float(beta), "se": float(s), "z": float(z), "odds_ratio": float(np.exp(beta)),
        "or_ci95": [float(np.exp(beta - 1.959964 * s)), float(np.exp(beta + 1.959964 * s))],
        "p_wald": float(p_wald), "lr_stat": float(lr), "lr_df": int(df),
        "p_lrt": float(stats.chi2.sf(lr, df)), "n": int(len(y)), "events": int(y.sum()),
        "converged": bool(full.converged_),
    }


def tpm2_slope_test(cohort: pd.DataFrame) -> dict:
    X = cohort[["tpm2_z"]].to_numpy(float)
    return wald_and_lrt(X, cohort["progression_12m"].to_numpy(), test_index=0)


def interaction_test(cohort: pd.DataFrame, group_col: str, positive_level: str) -> dict:
    """TPM2 x binary-group interaction. Rows with a missing group are dropped."""
    d = cohort[cohort[group_col].notna()]
    g = (d[group_col] == positive_level).astype(float).to_numpy()
    x = d["tpm2_z"].to_numpy(float)
    y = d["progression_12m"].to_numpy()
    X_full = np.column_stack([x, g, x * g])
    X_red = np.column_stack([x, g])
    out = wald_and_lrt(X_full, y, test_index=2, X_reduced=X_red)
    out.update({"group": group_col, "coded_as_1": positive_level})
    return out
