"""Analysis code for "Predicting Burkitt Lymphoma Progression Using ML"
(TPM2 expression, logistic regression via gradient ascent).

The package implements the methodology of the written report and reproduces the
original TPM2-only analysis script (fold seed 20261115) to rounding precision.
Every number is computed from the public cBioPortal data at run time; values
quoted in the report (reported_values.py) are used only for comparison.
"""

__version__ = "1.1.0"
