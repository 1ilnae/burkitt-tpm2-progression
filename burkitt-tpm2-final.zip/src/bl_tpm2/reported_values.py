"""Numbers quoted in the written report (updated version, November 2026).

These are used ONLY to build the side-by-side comparison table
(results/comparison_to_report.md) and the reference markers in two figures.
They are never used as inputs, targets, seeds, or tuning criteria for any
computation in this package.

The updated report no longer contains the former Section 8 (age-only, clinical
and combined model AUCs, mean ages, centre counts, leave-one-centre-out), so
those analyses are still computed by the pipeline but have no reported value to
compare against.
"""

REPORTED = {
    # Section 3 - cohort and endpoint
    "cohort.working_n": 209,
    "cohort.eligible_n": 166,
    "cohort.events": 71,
    "cohort.non_events": 95,
    "cohort.excluded_n": 43,
    # Section 6 - agreement with scikit-learn
    "verify.max_abs_prob_diff": 7e-9,
    # Section 7 - primary TPM2 results
    "tpm2.auc": 0.601,
    "tpm2.balanced_accuracy": 0.502,
    "tpm2.log_loss": 0.679,
    "baseline.balanced_accuracy": 0.500,
    "baseline.log_loss": 0.683,
    "tpm2.p_wald": 0.076,
    "tpm2.p_lrt": 0.055,
    # Figure 3 legend - pooled out-of-fold AUC of a single CV repeat ("CV repeat 1")
    "tpm2.roc_repeat1_pooled_auc": 0.591,
    # Section 9 - subgroups and interactions
    "subgroup.EBV-positive.n": 85,
    "subgroup.EBV-positive.events": 44,
    "subgroup.EBV-positive.auc": 0.547,
    "subgroup.EBV-negative.n": 81,
    "subgroup.EBV-negative.events": 27,
    "subgroup.EBV-negative.auc": 0.507,
    "subgroup.Pediatric.n": 97,
    "subgroup.Pediatric.events": 53,
    "subgroup.Pediatric.auc": 0.530,
    "subgroup.Adult.n": 68,
    "subgroup.Adult.events": 17,
    "subgroup.Adult.auc": 0.508,
    "subgroup.age_unknown.n": 1,
    "interaction.ebv.p": 0.446,
    "interaction.age_category.p": 0.653,
}
