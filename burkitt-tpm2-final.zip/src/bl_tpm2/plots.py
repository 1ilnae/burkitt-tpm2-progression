"""Publication-quality figures (matplotlib, 300 dpi PNG + vector PDF).

Figures 1-3 correspond to Figures 1-3 of the written report; the rest are
supporting and extension figures.
"""
from __future__ import annotations

import warnings
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.metrics import roc_auc_score, roc_curve  # noqa: E402

from .logistic import GradientAscentLogisticRegression, sigmoid  # noqa: E402

# Fixed categorical order (validated colour-blind-safe reference palette).
BLUE, ORANGE, AQUA, YELLOW, MAGENTA = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"
MODEL_COLORS = {"TPM2 only": BLUE, "Age only": ORANGE,
                "Clinical (age, sex, EBV, HIV)": AQUA, "TPM2 + clinical": MAGENTA}
INK, INK2, GRID, MUTED = "#0b0b0b", "#52514e", "#e4e3df", "#9a9993"

plt.rcParams.update({
    "font.family": "sans-serif", "font.size": 10, "axes.titlesize": 11,
    "axes.titleweight": "bold", "axes.labelcolor": INK2, "axes.edgecolor": MUTED,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False,
    "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.8, "legend.frameon": False, "figure.dpi": 110,
})


def _save(fig, out_dir: Path, name: str):
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / f"{name}.png", dpi=300, bbox_inches="tight")
    fig.savefig(out_dir / f"{name}.pdf", bbox_inches="tight")
    plt.close(fig)


# --- Report Figure 1 -------------------------------------------------------------------
def gradient_convergence(x_std: np.ndarray, y: np.ndarray, out_dir: Path,
                         rates=(0.001, 0.01, 0.1, 0.3), n_steps: int = 3000) -> dict:
    """Mean log-likelihood vs iteration for fixed learning rates (full cohort, standardised TPM2)."""
    fig, ax = plt.subplots(figsize=(7, 4))
    finals = {}
    for rate, col in zip(rates, [BLUE, ORANGE, AQUA, MAGENTA]):
        m = GradientAscentLogisticRegression(learning_rate=rate, max_iter=n_steps, tol=0.0, record_history=True)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            m.fit(x_std, y)
        h = m.history_ / len(y)
        finals[rate] = float(h[-1])
        ax.plot(np.arange(len(h)), h, color=col, lw=2, label=f"α = {rate:g}")
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Mean log-likelihood ℓ(β)/n")
    ax.set_title("Gradient-ascent convergence (real cohort)")
    ax.legend(loc="lower right", fontsize=8.5)
    fig.tight_layout()
    _save(fig, out_dir, "fig01_gradient_convergence")
    return finals


# --- Report Figure 2 -------------------------------------------------------------------
def tpm2_distribution(cohort: pd.DataFrame, out_dir: Path):
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.8), gridspec_kw={"width_ratios": [1.5, 1]})
    groups = [(0, "No progression by 12 mo", BLUE), (1, "Progression ≤ 12 mo", ORANGE)]
    bins = np.linspace(cohort.tpm2_z.min(), cohort.tpm2_z.max(), 26)
    ax = axes[0]
    for lab, name, col in groups:
        v = cohort.loc[cohort.progression_12m == lab, "tpm2_z"]
        ax.hist(v, bins=bins, density=True, alpha=0.45, color=col, edgecolor="white", linewidth=1,
                label=f"{name} (n={len(v)})")
    ax.set_xlabel("TPM2 mRNA expression z-score")
    ax.set_ylabel("Density")
    ax.set_title("TPM2 distributions overlap")
    ax.legend(loc="upper right", fontsize=8.5)
    ax = axes[1]
    rng = np.random.default_rng(0)
    data = [cohort.loc[cohort.progression_12m == lab, "tpm2_z"].to_numpy() for lab, _, _ in groups]
    bp = ax.boxplot(data, positions=[0, 1], widths=0.5, showfliers=False, patch_artist=True,
                    medianprops={"color": INK, "linewidth": 1.5})
    for patch in bp["boxes"]:
        patch.set(facecolor="none", edgecolor=INK2)
    for i, (v, (_, _, col)) in enumerate(zip(data, groups)):
        ax.scatter(i + rng.uniform(-0.17, 0.17, len(v)), v, s=12, color=col, alpha=0.7,
                   edgecolor="white", linewidth=0.4, zorder=3)
    ax.set_xticks([0, 1], ["No event\nby 12 mo", "Event\n≤ 12 mo"])
    ax.set_ylabel("TPM2 z-score")
    ax.set_title("Per-patient values")
    ax.grid(axis="x", visible=False)
    fig.tight_layout()
    _save(fig, out_dir, "fig02_tpm2_by_outcome")


# --- Report Figure 3 -------------------------------------------------------------------
def roc_single_repeat(res, out_dir: Path, repeat: int = 0):
    fig, ax = plt.subplots(figsize=(5.2, 5))
    ax.plot([0, 1], [0, 1], ls="--", color=MUTED, lw=1.2)
    for label, p, col in (("TPM2 logistic regression", res.oof[repeat], BLUE),
                          ("Prevalence-only baseline", res.base_oof[repeat], ORANGE)):
        fpr, tpr, _ = roc_curve(res.y, p)
        ax.plot(fpr, tpr, color=col, lw=2, label=f"{label} (AUC {roc_auc_score(res.y, p):.3f})")
    ax.set_xlabel("False-positive rate (1 − specificity)")
    ax.set_ylabel("True-positive rate (sensitivity)")
    ax.set_title(f"Out-of-fold ROC (CV repeat {repeat + 1})")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.01); ax.set_aspect("equal")
    ax.legend(loc="lower right", fontsize=8)
    _save(fig, out_dir, "fig03_roc_tpm2_repeat1")


# --- Supporting figures ------------------------------------------------------------------
def descriptive_fit(cohort: pd.DataFrame, beta: np.ndarray, mu: float, sd: float, out_dir: Path):
    """Full-sample fitted probability curve (descriptive only, not CV performance)."""
    x, y = cohort.tpm2_z.to_numpy(float), cohort.progression_12m.to_numpy(int)
    xx = np.linspace(np.quantile(x, 0.01), np.quantile(x, 0.99), 200)
    fig, ax = plt.subplots(figsize=(7, 4))
    rng = np.random.default_rng(1)
    ax.scatter(x, y + rng.uniform(-0.03, 0.03, len(y)), s=14, color=MUTED, alpha=0.6,
               edgecolor="none", label="Observed outcome (0/1, jittered)")
    ax.plot(xx, sigmoid(beta[0] + beta[1] * (xx - mu) / sd), color=BLUE, lw=2,
            label="Full-sample fitted probability")
    ax.set_xlabel("TPM2 z-score")
    ax.set_ylabel("Outcome / predicted probability")
    ax.set_title("TPM2-only logistic fit (descriptive, in-sample)")
    ax.legend(loc="center right", fontsize=8)
    fig.tight_layout()
    _save(fig, out_dir, "fig04_descriptive_logistic_fit")


def heldout_predictions(res, out_dir: Path, repeat: int = 0):
    p, y = res.oof[repeat], res.y
    order = np.argsort(p)
    fig, ax = plt.subplots(figsize=(7, 4))
    for lab, name, col in ((0, "No event by 12 mo", BLUE), (1, "Event ≤ 12 mo", ORANGE)):
        idx = np.where(y[order] == lab)[0]
        ax.scatter(idx, p[order][idx], s=14, color=col, label=name, edgecolor="white", linewidth=0.3)
    ax.axhline(0.5, ls="--", color=MUTED, lw=1)
    ax.set_xlabel("Patients sorted by out-of-fold predicted probability")
    ax.set_ylabel("Predicted 12-month event probability")
    ax.set_title(f"Held-out TPM2 predictions (CV repeat {repeat + 1})")
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    _save(fig, out_dir, "fig05_heldout_predictions")


def roc_all_models(results: dict, out_dir: Path):
    """Mean ROC over the repeats (pooled out-of-fold predictions per repeat)."""
    grid = np.linspace(0, 1, 201)
    fig, ax = plt.subplots(figsize=(5.2, 5))
    ax.plot([0, 1], [0, 1], ls="--", color=MUTED, lw=1.2, label="Chance (AUC 0.50)")
    for name, res in results.items():
        tprs = np.array([np.interp(grid, *roc_curve(res.y, res.oof[r])[:2]) for r in range(res.oof.shape[0])])
        col = MODEL_COLORS.get(name, BLUE)
        ax.plot(grid, tprs.mean(0), color=col, lw=2, label=f"{name} (AUC {res.summary()['auc_mean']:.3f})")
        if name == "TPM2 only":
            ax.fill_between(grid, np.percentile(tprs, 5, 0), np.percentile(tprs, 95, 0), color=col, alpha=0.12, lw=0)
    ax.set_xlabel("False-positive rate (1 − specificity)")
    ax.set_ylabel("True-positive rate (sensitivity)")
    ax.set_title("Cross-validated ROC, all models (10 × 5-fold)")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.01); ax.set_aspect("equal")
    ax.legend(loc="lower right", fontsize=7.8)
    _save(fig, out_dir, "fig06_roc_all_models")


def model_comparison(results: dict, reported: dict, out_dir: Path):
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    names = list(results)
    for i, name in enumerate(names):
        pr = results[name].per_repeat()
        aucs = pr.loc[pr.model == name, "auc"].to_numpy()
        col = MODEL_COLORS.get(name, BLUE)
        ax.scatter(aucs, np.full(len(aucs), i) + np.random.default_rng(i).uniform(-0.15, 0.15, len(aucs)),
                   s=18, color=col, alpha=0.6, edgecolor="none")
        m = aucs.mean()
        ax.plot([m, m], [i - 0.3, i + 0.3], color=INK, lw=2)
        ax.text(m + 0.003, i - 0.3, f"mean {m:.3f}", ha="left", va="center", fontsize=8.5, color=INK)
        rep = reported.get("tpm2.auc") if name == "TPM2 only" else None
        if rep is not None:
            ax.scatter([rep], [i], marker="D", s=40, facecolor="white", edgecolor=INK, zorder=4,
                       label="Value in written report")
    ax.axvline(0.5, ls="--", color=MUTED, lw=1)
    ax.set_yticks(range(len(names)), names)
    ax.invert_yaxis()
    ax.set_xlabel("Out-of-fold ROC-AUC (dots = 10 CV repeats, bar = mean)")
    ax.set_title("Model comparison: none is a reliable predictor")
    ax.grid(axis="y", visible=False)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    _save(fig, out_dir, "fig07_model_comparison")


def metric_panel(summary: pd.DataFrame, out_dir: Path):
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.2))
    names = ["Prevalence baseline"] + list(summary["model"])
    ba = [summary["baseline_balanced_accuracy_mean"].iloc[0]] + list(summary["balanced_accuracy_mean"])
    ll = [summary["baseline_log_loss_mean"].iloc[0]] + list(summary["log_loss_mean"])
    cols = [MUTED] + [MODEL_COLORS.get(n, BLUE) for n in summary["model"]]
    for ax, vals, title, lim in [(axes[0], ba, "Balanced accuracy (↑)", (0.4, 0.68)),
                                 (axes[1], ll, "Log loss (↓)", None)]:
        y = np.arange(len(names))
        ax.barh(y, vals, color=cols, height=0.6, edgecolor="white", linewidth=2)
        for yi, v in zip(y, vals):
            ax.text(v, yi, f" {v:.3f}", va="center", fontsize=8.5, color=INK)
        ax.set_yticks(y, names if ax is axes[0] else [""] * len(names))
        ax.invert_yaxis()
        ax.set_title(title)
        ax.grid(axis="y", visible=False)
        ax.set_xlim(*(lim or (min(vals) - 0.03, max(vals) + 0.03)))
    fig.tight_layout()
    _save(fig, out_dir, "fig08_metrics_vs_baseline")


def subgroup_chart(sub: pd.DataFrame, out_dir: Path):
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    y = np.arange(len(sub))
    ax.errorbar(sub["auc_mean"], y, xerr=sub["auc_sd"], fmt="o", color=BLUE, ms=7,
                ecolor=MUTED, elinewidth=1.5, capsize=3, label="Computed (mean ± SD over repeats)")
    ax.scatter(sub["reported_auc"], y, marker="D", s=36, facecolor="white", edgecolor=INK,
               zorder=4, label="Value in written report")
    ax.axvline(0.5, ls="--", color=MUTED, lw=1)
    ax.set_yticks(y, [f"{s} (n={n}, {e} events)" for s, n, e in zip(sub["subgroup"], sub["n"], sub["events"])])
    ax.invert_yaxis()
    ax.set_xlabel("TPM2-only out-of-fold ROC-AUC")
    ax.set_title("Exploratory subgroups")
    ax.grid(axis="y", visible=False)
    ax.legend(loc="upper center", bbox_to_anchor=(0.35, -0.22), fontsize=7.5, ncol=2)
    fig.tight_layout()
    _save(fig, out_dir, "fig09_subgroups")


def center_chart(loco: dict, counts: pd.DataFrame, out_dir: Path):
    """Left: event rate per centre. Right: leave-one-centre-out AUC per model."""
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), gridspec_kw={"width_ratios": [1, 1.2]})
    c = counts.sort_values("n", ascending=True)
    ax = axes[0]
    ax.barh(c["center"], c["event_rate"], color=BLUE, height=0.6, edgecolor="white", linewidth=2)
    for yi, (r, n, e) in enumerate(zip(c["event_rate"], c["n"], c["events"])):
        ax.text(r, yi, f" {e}/{n}", va="center", fontsize=8, color=INK)
    ax.set_xlim(0, 1)
    ax.set_xlabel("Observed 12-month progression rate")
    ax.set_title("Event rates differ by centre")
    ax.grid(axis="y", visible=False)
    ax = axes[1]
    order = list(c["center"])
    for k, (name, (table, _)) in enumerate(loco.items()):
        t = table.set_index("center").reindex(order)
        ax.scatter(t["auc"], np.arange(len(order)) + (k - 1.5) * 0.09, s=26,
                   color=MODEL_COLORS.get(name, BLUE), label=name, edgecolor="white", linewidth=0.5, zorder=3)
    ax.axvline(0.5, ls="--", color=MUTED, lw=1)
    ax.set_yticks(range(len(order)), [""] * len(order))
    for yi in range(len(order)):
        ax.axhline(yi, color=GRID, lw=0.6, zorder=0)
    ax.set_xlim(0, 1)
    ax.set_xlabel("AUC on withheld centre (blank = one outcome class only)")
    ax.set_title("Leave-one-centre-out validation")
    ax.grid(axis="y", visible=False)
    ax.legend(loc="lower left", fontsize=7, bbox_to_anchor=(0, -0.42), ncol=2)
    fig.tight_layout()
    _save(fig, out_dir, "fig10_centers")


def sklearn_agreement(diffs: dict, out_dir: Path):
    fig, ax = plt.subplots(figsize=(6.4, 2.8))
    names = list(diffs)
    vals = [max(diffs[n], 1e-16) for n in names]
    ax.barh(names, vals, color=[MODEL_COLORS.get(n, BLUE) for n in names], height=0.55,
            edgecolor="white", linewidth=2)
    ax.set_xscale("log")
    ax.set_xlim(1e-11, 1e-5)
    for yi, v in enumerate(vals):
        ax.text(v, yi, f" {v:.1e}", va="center", fontsize=8, color=INK)
    ax.invert_yaxis()
    ax.set_xlabel("Max |p_gradient-ascent − p_sklearn| over all held-out folds")
    ax.set_title("Agreement with scikit-learn (unpenalised)")
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    _save(fig, out_dir, "fig11_sklearn_agreement")
