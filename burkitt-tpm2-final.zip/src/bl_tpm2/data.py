"""Download the public mbn_sfu_2023 study from the cBioPortal REST API.

Three resources are fetched and cached as raw JSON under ``data/raw/``:

* patient-level clinical data   (age, sex, EBV, HIV, PFS_MONTHS, PFS_STATUS, ...)
* sample-level clinical data    (cancer type, collection centre = SOURCE, ...)
* TPM2 mRNA expression z-scores (profile ``mbn_sfu_2023_rna_seq_mrna_median_Zscores``)

Nothing is synthesised: if the API cannot be reached and no cache exists, the
pipeline stops with an explanatory error.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import requests

API = "https://www.cbioportal.org/api"
STUDY_ID = "mbn_sfu_2023"
EXPRESSION_PROFILE = f"{STUDY_ID}_rna_seq_mrna_median_Zscores"
SAMPLE_LIST = f"{STUDY_ID}_all"
GENE_SYMBOL = "TPM2"
TIMEOUT = 60


class DataUnavailableError(RuntimeError):
    """Raised when the real study data cannot be obtained."""


def _get(url: str, **kwargs):
    r = requests.get(url, timeout=TIMEOUT, headers={"Accept": "application/json"}, **kwargs)
    r.raise_for_status()
    return r.json()


def _post(url: str, payload: dict):
    r = requests.post(url, json=payload, timeout=TIMEOUT,
                      headers={"Accept": "application/json", "Content-Type": "application/json"})
    r.raise_for_status()
    return r.json()


def download_raw(raw_dir: Path, force: bool = False) -> dict[str, Path]:
    """Download (or reuse cached) raw JSON files. Returns their paths."""
    raw_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "study": raw_dir / "study.json",
        "patient_clinical": raw_dir / "patient_clinical.json",
        "sample_clinical": raw_dir / "sample_clinical.json",
        "gene": raw_dir / "gene_tpm2.json",
        "tpm2_expression": raw_dir / "tpm2_expression_zscores.json",
    }
    if not force and all(p.exists() for p in paths.values()):
        return paths
    try:
        study = _get(f"{API}/studies/{STUDY_ID}")
        gene = _get(f"{API}/genes/{GENE_SYMBOL}")
        patient = _get(f"{API}/studies/{STUDY_ID}/clinical-data",
                       params={"clinicalDataType": "PATIENT", "projection": "SUMMARY", "pageSize": 100000})
        sample = _get(f"{API}/studies/{STUDY_ID}/clinical-data",
                      params={"clinicalDataType": "SAMPLE", "projection": "SUMMARY", "pageSize": 100000})
        expr = _post(f"{API}/molecular-profiles/{EXPRESSION_PROFILE}/molecular-data/fetch?projection=SUMMARY",
                     {"sampleListId": SAMPLE_LIST, "entrezGeneIds": [int(gene["entrezGeneId"])]})
    except requests.RequestException as exc:  # pragma: no cover - network dependent
        raise DataUnavailableError(
            "Could not download mbn_sfu_2023 from cBioPortal "
            f"({exc}). Check your internet connection, or place previously downloaded "
            "raw JSON files in data/raw/. No synthetic data will be substituted."
        ) from exc
    for key, obj in [("study", study), ("gene", gene), ("patient_clinical", patient),
                     ("sample_clinical", sample), ("tpm2_expression", expr)]:
        paths[key].write_text(json.dumps(obj, indent=1))
    return paths


def _pivot_clinical(records: list[dict], id_col: str) -> pd.DataFrame:
    df = pd.DataFrame(records)
    wide = df.pivot(index=id_col, columns="clinicalAttributeId", values="value")
    if id_col == "sampleId":
        wide["patientId"] = df.groupby("sampleId")["patientId"].first()
    wide.columns.name = None
    return wide


def load_merged(raw_dir: Path, force_download: bool = False) -> pd.DataFrame:
    """Return one row per sample with TPM2 z-score joined to sample + patient clinical data."""
    paths = download_raw(raw_dir, force=force_download)
    patient = _pivot_clinical(json.loads(paths["patient_clinical"].read_text()), "patientId")
    sample = _pivot_clinical(json.loads(paths["sample_clinical"].read_text()), "sampleId")
    expr = pd.DataFrame(json.loads(paths["tpm2_expression"].read_text()))
    if expr.empty:
        raise DataUnavailableError("cBioPortal returned no TPM2 expression values.")
    expr = expr[["sampleId", "patientId", "value"]].rename(columns={"value": "tpm2_z"})
    expr["tpm2_z"] = pd.to_numeric(expr["tpm2_z"], errors="coerce")

    merged = (expr
              .merge(sample.drop(columns=["patientId"]), left_on="sampleId", right_index=True, how="left")
              .merge(patient, left_on="patientId", right_index=True, how="left"))
    return merged
