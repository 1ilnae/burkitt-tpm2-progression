#!/usr/bin/env python3
"""Convenience entry point: `python run_analysis.py [--refresh] [--seed N]`."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from bl_tpm2.pipeline import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
