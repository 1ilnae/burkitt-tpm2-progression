"""Endpoint rules and CV mechanics on hand-written illustrative rows (NOT study patients)."""
import numpy as np
import pandas as pd

from bl_tpm2.cohort import build_endpoint
from bl_tpm2.evaluation import FoldPreprocessor, repeated_cv


def test_endpoint_rules():
    months = pd.Series([3.0, 12.0, 12.0, 30.0, 30.0, 6.0, np.nan, 11.9])
    status = pd.Series(["1:Progression",      # event at 3 mo           -> 1
                        "1:Progression",      # event exactly at 12 mo  -> 1
                        "0:ProgressionFree",  # censored exactly at 12  -> 0
                        "0:ProgressionFree",  # censored at 30          -> 0
                        "1:Progression",      # event after 12 mo       -> 0 (PFS at 12 mo)
                        "0:ProgressionFree",  # censored at 6 mo        -> excluded
                        "1:Progression",      # missing time            -> excluded
                        None])                # missing status          -> excluded
    y = build_endpoint(months, status)
    assert y.iloc[:5].tolist() == [1.0, 1.0, 0.0, 0.0, 0.0]
    assert y.iloc[5:].isna().all()


def test_preprocessor_uses_training_statistics_only():
    train = pd.DataFrame({"age": [10.0, 20.0, np.nan], "sex": ["Male", "Female", None]})
    test = pd.DataFrame({"age": [np.nan, 40.0], "sex": ["Female", "Other"]})
    pre = FoldPreprocessor(["age", "sex"]).fit(train)
    Xt = pre.transform(test)
    # median of train = 15 -> standardised with train mean/sd of [10, 20, 15]
    mean, sd = 15.0, np.std([10.0, 20.0, 15.0])
    np.testing.assert_allclose(Xt[:, 0], [(15 - mean) / sd, (40 - mean) / sd])
    assert pre.feature_names() == ["age", "sex=Male"]
    np.testing.assert_allclose(Xt[:, 1], [0.0, 0.0])        # unseen level -> reference


def test_repeated_cv_shapes_and_baseline():
    rng = np.random.default_rng(0)
    n = 60
    df = pd.DataFrame({"tpm2_z": rng.normal(size=n), "progression_12m": rng.binomial(1, 0.4, n)})
    res = repeated_cv(df, ["tpm2_z"], "toy", n_splits=5, n_repeats=3, seed=1)
    assert len(res.folds) == 15
    assert res.oof.shape == (3, n) and not np.isnan(res.oof).any()
    assert res.sklearn_max_abs_diff < 1e-6
    # each repeat gives exactly one held-out prediction per patient
    assert res.per_repeat().shape[0] == 6          # 3 repeats x (model, baseline)
    base = res.per_repeat().query("model == 'Prevalence-only baseline'")
    # baseline predicts one class at threshold 0.5 -> balanced accuracy exactly 0.5
    np.testing.assert_allclose(base["balanced_accuracy"], 0.5)
    s = res.summary()
    assert 0 <= s["auc_mean"] <= 1 and s["brier_mean"] > 0


def test_metrics_match_definitions():
    from bl_tpm2.evaluation import metrics
    y = np.array([0, 0, 1, 1])
    p = np.array([0.1, 0.6, 0.4, 0.9])
    m = metrics(y, p)
    assert m["auc"] == 0.75                                    # 3 of 4 event/non-event pairs ranked correctly
    assert m["balanced_accuracy"] == 0.5                       # sens 0.5, spec 0.5 at threshold 0.5
    assert np.isclose(m["brier"], np.mean((p - y) ** 2))
    assert np.isclose(m["log_loss"], -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))
