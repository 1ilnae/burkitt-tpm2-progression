"""Unit tests for the from-scratch optimiser.

All inputs here are small illustrative arrays or random numbers generated in
the test - NOT study patients.
"""
import numpy as np
import pytest
from scipy import stats

from bl_tpm2.evaluation import sklearn_unpenalised
from bl_tpm2.inference import wald_and_lrt
from bl_tpm2.logistic import (GradientAscentLogisticRegression, add_intercept, gradient,
                              hessian, log_likelihood, sigmoid)


def _toy(n=200, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n, 3))
    p = sigmoid(0.3 + X @ np.array([0.8, -0.5, 0.0]))
    return X, rng.binomial(1, p)


def test_sigmoid_values_and_stability():
    assert sigmoid(np.array([0.0]))[0] == 0.5
    z = np.array([-1000.0, -30.0, 30.0, 1000.0])
    s = sigmoid(z)
    assert np.all(np.isfinite(s)) and s[0] == 0.0 and s[-1] == 1.0
    np.testing.assert_allclose(sigmoid(z) + sigmoid(-z), 1.0)


def test_log_likelihood_matches_bernoulli_definition():
    X, y = _toy(50)
    D = add_intercept(X)
    beta = np.array([0.1, 0.2, -0.3, 0.4])
    p = sigmoid(D @ beta)
    direct = np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))
    assert log_likelihood(beta, D, y) == pytest.approx(direct, rel=1e-12)


def test_analytical_gradient_matches_finite_differences():
    X, y = _toy(80, seed=1)
    D = add_intercept(X)
    beta = np.array([0.2, -0.1, 0.5, 0.3])
    eps = 1e-6
    num = np.array([(log_likelihood(beta + eps * e, D, y) - log_likelihood(beta - eps * e, D, y)) / (2 * eps)
                    for e in np.eye(len(beta))])
    np.testing.assert_allclose(gradient(beta, D, y), num, rtol=1e-6, atol=1e-6)


def test_hessian_matches_finite_differences_of_gradient():
    X, y = _toy(60, seed=2)
    D = add_intercept(X)
    beta = np.array([0.1, 0.4, -0.2, 0.0])
    eps = 1e-6
    num = np.column_stack([(gradient(beta + eps * e, D, y) - gradient(beta - eps * e, D, y)) / (2 * eps)
                           for e in np.eye(len(beta))])
    np.testing.assert_allclose(hessian(beta, D), num, rtol=1e-5, atol=1e-5)


def test_first_step_reproduces_report_worked_example():
    # x = [-1, +1], y = [0, 1], alpha = 0.2  ->  beta0 = 0, beta1 = 0.10 after one step
    with pytest.warns(RuntimeWarning):   # one step is (correctly) reported as not converged
        m = GradientAscentLogisticRegression(learning_rate=0.2, max_iter=1).fit(np.array([[-1.0], [1.0]]), [0, 1])
    assert m.intercept_ == pytest.approx(0.0)
    assert m.coef_[0] == pytest.approx(0.10)


def test_converges_monotonically_and_matches_sklearn():
    X, y = _toy(300, seed=3)
    m = GradientAscentLogisticRegression(record_history=True).fit(X, y)
    assert m.converged_ and m.monotone_
    assert np.all(np.diff(m.history_) >= -1e-10)
    sk = sklearn_unpenalised().fit(X, y)
    np.testing.assert_allclose(m.coef_, sk.coef_.ravel(), atol=1e-6)
    assert np.max(np.abs(m.predict_proba(X)[:, 1] - sk.predict_proba(X)[:, 1])) < 1e-7


def test_fixed_small_step_reaches_same_optimum():
    X, y = _toy(150, seed=4)
    a = GradientAscentLogisticRegression().fit(X, y)
    b = GradientAscentLogisticRegression(learning_rate=0.2).fit(X, y)
    np.testing.assert_allclose(a.beta_, b.beta_, atol=1e-6)


def test_separation_is_flagged_not_silently_accepted():
    X = np.array([[-2.0], [-1.0], [1.0], [2.0]])
    with pytest.warns(RuntimeWarning):
        m = GradientAscentLogisticRegression(max_iter=2000).fit(X, [0, 0, 1, 1])
    assert not m.converged_


def test_wald_and_lrt_against_statsmodels():
    sm = pytest.importorskip("statsmodels.api")
    X, y = _toy(250, seed=5)
    res = wald_and_lrt(X[:, :1], y, test_index=0)
    ref = sm.Logit(y, sm.add_constant(X[:, :1])).fit(disp=0)
    assert res["p_wald"] == pytest.approx(ref.pvalues[1], rel=1e-5)
    assert res["p_lrt"] == pytest.approx(stats.chi2.sf(2 * (ref.llf - ref.llnull), 1), rel=1e-5)


def test_input_validation():
    with pytest.raises(ValueError):
        GradientAscentLogisticRegression().fit([[1.0], [np.nan]], [0, 1])
    with pytest.raises(ValueError):
        GradientAscentLogisticRegression().fit([[1.0], [2.0]], [0, 2])
