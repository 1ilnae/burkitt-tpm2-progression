"""The verification module must pass on well-posed data and its independent solver must agree.

Illustrative random data only - NOT study patients.
"""
import numpy as np

from bl_tpm2.logistic import GradientAscentLogisticRegression, add_intercept
from bl_tpm2.verification import all_passed, newton_raphson, to_markdown, verify


def _data(seed=0, n=166):
    rng = np.random.default_rng(seed)
    x = rng.normal(size=(n, 1))
    y = rng.binomial(1, 1 / (1 + np.exp(-(-0.3 - 0.3 * x[:, 0]))))
    return x, y


def test_newton_raphson_matches_gradient_ascent():
    x, y = _data()
    ga = GradientAscentLogisticRegression().fit(x, y)
    np.testing.assert_allclose(newton_raphson(add_intercept(x), y), ga.beta_, atol=1e-8)


def test_all_checks_pass_on_well_posed_problem():
    x, y = _data(1)
    v = verify(x, y, GradientAscentLogisticRegression().fit(x, y))
    md = to_markdown(v)
    assert all_passed(md), md
    assert v["strictly_concave"] and v["converged"] and v["monotone_ascent"]
