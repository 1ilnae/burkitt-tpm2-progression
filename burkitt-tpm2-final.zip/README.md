# Predicting Burkitt Lymphoma Progression Using Machine Learning

**TPM2 expression, logistic regression by gradient ascent, and limited clinical information**
Graduate final project · *Essential Mathematics for Data Science & AI* · November 2026

This repository contains the written report and the complete, reproducible Python analysis.
One command downloads the public data from cBioPortal, builds the cohort, fits logistic
regression with a hand-coded gradient-ascent optimiser, verifies the mathematics, runs repeated
cross-validation, and regenerates every table and figure.

> [!WARNING]
> Educational, exploratory research only. Do not use it to estimate any individual's prognosis
> or to guide treatment.

---

## 1. Research question

Can the expression of a single gene, **TPM2**, predict a recorded **progression event within
12 months** in Burkitt lymphoma patients the model was not trained on? Secondary questions: does
TPM2 behave differently by EBV status or age group, and do simple clinical variables add anything?

## 2. Quick start on a Mac

You need Python 3.10 or newer (`python3 --version`). If you don't have it, install it from
[python.org](https://www.python.org/downloads/macos/). Open **Terminal** in the project folder
(after cloning, `cd` into the repository), then run:

```bash
python3 -m venv .venv
```

```bash
source .venv/bin/activate
```

```bash
python -m pip install -r requirements.txt
```

```bash
python -m pytest -q
```

```bash
python run_analysis.py
```

The first run downloads about 1.2 MB from the cBioPortal public API into `data/raw/`. The whole
analysis takes under 30 seconds. It overwrites `results/` and `figures/` and prints how many of the
report's numbers it reproduces.

| Option | Effect |
|---|---|
| `--refresh` | Re-download the data (cBioPortal may update the study) |
| `--seed N` | Different CV fold assignment (default `20261115`, as used for the report) |
| `--repeats N` | Number of CV repetitions (default 10) |

Troubleshooting: `xcrun: error` → run `xcode-select --install` once. `ModuleNotFoundError` →
run `source .venv/bin/activate` again in this Terminal window. If the download fails, the code
stops with a message; it never substitutes synthetic data.

## 3. Repository layout

```
├── run_analysis.py                  # the single entry point
├── requirements.txt
├── Final Project Written Project Report.pdf
├── src/bl_tpm2/
│   ├── data.py                      # cBioPortal REST download + merge (study mbn_sfu_2023)
│   ├── cohort.py                    # Burkitt cohort + 12-month endpoint
│   ├── logistic.py                  # sigmoid, log-likelihood, gradient, Hessian, gradient ascent
│   ├── verification.py              # numerical checks of the mathematics on the real cohort
│   ├── inference.py                 # Wald / likelihood-ratio / interaction tests
│   ├── evaluation.py                # fold preprocessing, repeated stratified CV, sklearn check, LOCO
│   ├── plots.py                     # figures (PNG 300 dpi + PDF)
│   ├── reported_values.py           # numbers quoted in the report, used ONLY for comparison
│   └── pipeline.py                  # orchestrates everything
├── tests/                           # 16 unit tests (illustrative data only, never patients)
├── results/                         # generated tables, comparison with the report, math checks
├── figures/                         # generated figures fig01–fig11
└── data/                            # raw/ and processed/ created at run time, git-ignored
```

### Where the code came from
The TPM2 analysis was first done in a single script, `analyze.py`, which produced the numbers and
Figures 1–3 in the report. This repository replaces it with the modular package above. The package
implements the same protocol (same endpoint rule, same fold seed `20261115`, standardisation within
training folds, pooled out-of-fold metrics per repeat). Checked against the original script's saved
outputs:

| Original `analyze.py` output | Modular package | Agreement |
|---|---|---|
| Cohort: 209 → 166 (71 / 95), patient order | identical | exact |
| Per-repeat AUC, balanced accuracy, log loss, Brier (10 repeats) | `results/cross_validation_metrics.csv` | BA exact; others ≤ 1.5 × 10⁻⁴ |
| Mean TPM2 AUC 0.601312 | 0.601312 on the same input values | exact |
| Fold coefficients vs scikit-learn | `results/handcoded_vs_sklearn.csv` | ≤ 1.2 × 10⁻⁵ |
| Max probability difference vs sklearn 6.94 × 10⁻⁹ | 6.93 × 10⁻⁹ | same |
| Figures: convergence, TPM2 by outcome, ROC repeat 1 | `fig01`, `fig02`, `fig03` | same curves and AUCs |

The tiny remaining differences on live data (for example AUC 0.60125 vs 0.60131) come from the
TPM2 z-scores served by cBioPortal today. They differ from the original download by up to
5 × 10⁻⁵, a rounding-level change. Every output of `analyze.py` is preserved in the package
(Brier score, descriptive fit, held-out prediction plot, learning-rate sweep), so the old script
was retired to avoid two entry points.

## 4. Data and endpoint (report §3)

- **Source:** cBioPortal study **`mbn_sfu_2023`** (Thomas et al., *Blood* 2023), fetched from the public
  REST API. Expression profile `mbn_sfu_2023_rna_seq_mrna_median_Zscores`, gene TPM2 (Entrez 7169).
  The clinical fields are age, age category, sex, EBV, HIV, PFS months, PFS status and collection centre (`SOURCE`).
- **Cohort:** `CANCER_TYPE_DETAILED == "Burkitt Lymphoma"` with a TPM2 value, which gives **209 patients**.
- **Endpoint:**

  | Label | Rule |
  |---|---|
  | `y = 1` | `PFS_STATUS = 1:Progression` and `PFS_MONTHS ≤ 12` |
  | `y = 0` | `PFS_MONTHS ≥ 12` with no progression by month 12 |
  | excluded | missing PFS data, or censored before 12 months |

  This gives 166 eligible patients (71 events, 95 non-events) and 43 excluded (12 missing, 31 censored early).
  11 of the 95 non-events progressed *after* month 12.

**Data licence and privacy.** cBioPortal data are released under the
[ODC Open Database License](https://opendatacommons.org/licenses/odbl/) with attribution to the
original study. Even so, **no patient-level records are committed to this repository**. The pipeline
rebuilds them locally (`data/raw/`, `data/processed/patient_level_model_data.csv`), and those paths
are git-ignored. The committed results are aggregate tables, plus figures showing de-identified
TPM2 values with no identifiers.

## 5. Mathematics (report §§4–5) and its verification

For patient *i* with design row x̃ᵢ = [1, xᵢ] and β = (β₀, β₁):

| Quantity | Formula | Code |
|---|---|---|
| Sigmoid | pᵢ = σ(zᵢ) = 1/(1+e^(−zᵢ)), zᵢ = x̃ᵢᵀβ | `logistic.sigmoid` (overflow-safe) |
| Bernoulli log-likelihood | ℓ(β) = Σ[yᵢ log pᵢ + (1−yᵢ) log(1−pᵢ)] = Σ[yᵢzᵢ − log(1+e^(zᵢ))] | `logistic.log_likelihood` |
| Gradient | ∇ℓ(β) = Xᵀ(y − p) | `logistic.gradient` |
| Hessian | ∇²ℓ(β) = −XᵀWX, W = diag(pᵢ(1−pᵢ)) | `logistic.hessian` |
| Update | g = Xᵀ(y−p)/n, β ← β + αg, starting from β = 0 | `GradientAscentLogisticRegression.fit` |
| Step size | α = 1/L with L = λ_max(XᵀX/n)/4 (guarantees monotone ascent); fixed α also supported | same |
| Stopping | ‖g‖∞ < 10⁻⁹; monotonicity flag; iteration cap with a warning (e.g. separation) | same |

Every run writes [`results/math_verification.md`](results/math_verification.md), checked on the
real cohort. All checks pass:

- the sigmoid's identities hold;
- the stable and textbook log-likelihood forms agree;
- the analytical gradient matches finite differences (≤ 6 × 10⁻⁹);
- the Hessian is negative definite, so the optimum is unique;
- one update equals β + αXᵀ(y−p)/n exactly;
- the fit converges monotonically in 16 iterations;
- β matches an independent Newton–Raphson solver, scikit-learn, and the original α = 0.2 / 5000-step schedule (all ≤ 7 × 10⁻⁹).

The same properties are covered by unit tests in `tests/`.

## 6. Validation design (report §§6–7, 9)

- `RepeatedStratifiedKFold(n_splits=5, n_repeats=10, random_state=20261115)`.
- Preprocessing is fitted on training folds only: median imputation and standardisation for numeric
  features; mode imputation and reference-coded indicators for categorical features.
- For each repeat, every patient receives one held-out probability. ROC-AUC, balanced accuracy
  (threshold 0.5), log loss and Brier score are computed on these pooled predictions and averaged over
  the 10 repeats. This is the report's "mean out-of-fold ROC-AUC". The mean of the 50 per-fold AUCs
  is also saved for reference.
- Prevalence-only baseline: each held-out patient gets the training-fold event rate.
- In-sample tests: Wald and likelihood-ratio tests for the TPM2 slope; TPM2 × EBV and TPM2 × age-category
  interaction tests (likelihood-ratio test, 1 df).
- Subgroups: TPM2-only repeated CV within EBV+, EBV−, paediatric and adult patients.
- Extensions not quantified in the report: age-only, clinical (age, sex, EBV, HIV) and combined models;
  leave-one-centre-out validation.

## 7. Results (computed by `python run_analysis.py`)

| Model | ROC-AUC (mean ± SD over repeats) | Balanced acc. | Log loss | Brier |
|---|---:|---:|---:|---:|
| Prevalence-only baseline | 0.494 | 0.500 | 0.683 | 0.245 |
| **TPM2 only** | **0.601 ± 0.014** | 0.502 | 0.679 | 0.241 |
| Age only | 0.612 ± 0.008 | 0.578 | 0.669 | 0.237 |
| Clinical (age, sex, EBV, HIV) | 0.603 ± 0.020 | 0.630 | 0.682 | 0.242 |
| TPM2 + clinical | 0.611 ± 0.018 | 0.623 | 0.683 | 0.242 |

- **TPM2 slope** (raw z-score): β = −0.317, OR 0.73 (95% CI 0.51–1.03); Wald p = 0.076, LRT p = 0.055.
  Higher TPM2 went with *lower* recorded 12-month progression. This is the opposite direction from the
  motivating Corinaldesi et al. cohort, but it is not statistically significant.
- **Subgroups** (TPM2-only AUC): EBV+ 0.531, EBV− 0.505, paediatric 0.548, adult 0.507.
- **Interactions** (LRT): TPM2 × EBV p = 0.446; TPM2 × age category p = 0.653.
- **Leave-one-centre-out** (extension), pooled AUC: TPM2 0.343, age 0.395, clinical 0.396, combined
  0.388. Centre event rates range from 0/7 to 39/55, and nothing generalises across centres.

### Figures
| File | Content |
|---|---|
| `fig01_gradient_convergence` | Report Figure 1: mean log-likelihood vs iteration, α = 0.001 / 0.01 / 0.1 / 0.3 |
| `fig02_tpm2_by_outcome` | Report Figure 2: TPM2 z-scores by 12-month outcome |
| `fig03_roc_tpm2_repeat1` | Report Figure 3: out-of-fold ROC, CV repeat 1 (TPM2 0.591, baseline 0.494) |
| `fig04_descriptive_logistic_fit` | Full-sample fitted probability curve (descriptive only) |
| `fig05_heldout_predictions` | Sorted held-out predicted probabilities, CV repeat 1 |
| `fig06_roc_all_models` | Mean ROC curves, all four models |
| `fig07_model_comparison` | AUC per CV repeat, all four models |
| `fig08_metrics_vs_baseline` | Balanced accuracy and log loss compared with the baseline |
| `fig09_subgroups` | TPM2-only AUC in EBV and age subgroups |
| `fig10_centers` | Event rate per centre; leave-one-centre-out AUC |
| `fig11_sklearn_agreement` | Gradient ascent vs scikit-learn, max probability difference |

### Result tables (`results/`)
`comparison_to_report.md` (every number in the report against the computed value) ·
`math_verification.md` · `model_comparison.csv` · `cross_validation_metrics.csv` (per repeat) ·
`handcoded_vs_sklearn.csv` (per fold) · `cv_folds_all_models.csv` · `subgroups.csv` ·
`leave_one_center_out.csv` · `center_event_counts.csv` · `results.json`.

## 8. Agreement with the written report

`results/comparison_to_report.md` is regenerated on every run. **26 of the 29 quantities quoted in
the report match**: cohort counts, TPM2 AUC 0.601, balanced accuracy 0.502, log loss 0.679, baseline
0.500 / 0.683, p-values 0.076 / 0.055 / 0.446 / 0.653, Figure 3's AUC 0.591, the sklearn agreement,
and all subgroup sizes and event counts.

The three subgroup AUCs that differ:

| Subgroup | Report | Computed |
|---|---:|---:|
| EBV-positive | 0.547 | 0.531 |
| EBV-negative | 0.507 | 0.505 |
| Paediatric | 0.530 | 0.548 |

The EBV-positive and paediatric values look **transposed** in the report: the computed EBV+ value
matches the reported paediatric value, and vice versa, each within 0.001. EBV-negative differs by
0.002, consistent with the rounding-level changes in the live data. The original subgroup script was
not available to confirm this.

## 9. Limitations
- Excluding 43 patients without a defensible 12-month label may cause selection bias. A
  censoring-aware survival model would avoid discarding them.
- This is observational multi-centre data. Centre is strongly linked to event rate and age.
- 166 patients and a limited feature set: no stage, LDH, CNS involvement or treatment data.
- Repeated CV folds are correlated and are not external validation. Several subgroup tests raise multiple-testing concerns.

## 10. References
- Thomas, N., et al. (2023). Genetic subgroups inform on pathobiology in adult and pediatric Burkitt
  lymphoma. *Blood*, 141(8), 904–916. <https://doi.org/10.1182/blood.2022016534>.
  Data: cBioPortal study [`mbn_sfu_2023`](https://www.cbioportal.org/study/summary?id=mbn_sfu_2023).
- Corinaldesi, C., et al. (2025). Single-cell transcriptomics of pediatric Burkitt lymphoma reveals
  intra-tumor heterogeneity and markers of therapy resistance. *Leukemia*, 39, 189–198.
  <https://doi.org/10.1038/s41375-024-02431-3>. This is the biological motivation only; that cohort is not analysed here.
- Cerami, E., et al. (2012). The cBio Cancer Genomics Portal. *Cancer Discovery*, 2(5), 401–404.
- Gao, J., et al. (2013). Integrative analysis of complex cancer genomics and clinical profiles using
  the cBioPortal. *Science Signaling*, 6(269), pl1.
