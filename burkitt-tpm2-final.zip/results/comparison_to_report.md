# Results vs. the written report

Generated automatically by `bl_tpm2.pipeline`. *Reported* values are copied from the PDF report; *computed* values are recomputed from the live cBioPortal data on every run. Reported values are never used in any computation.

AUC, balanced accuracy and log loss follow the report's protocol: metrics of the pooled out-of-fold predictions of each CV repeat, averaged over the 10 repeats. The last numeric column shows the alternative mean of the 50 per-fold AUCs for reference.

| Quantity | Reported | Computed | Mean of fold AUCs | Status |
|---|---:|---:|---:|---|
| `cohort.working_n` | 209 | 209 | — | match |
| `cohort.eligible_n` | 166 | 166 | — | match |
| `cohort.events` | 71 | 71 | — | match |
| `cohort.non_events` | 95 | 95 | — | match |
| `cohort.excluded_n` | 43 | 43 | — | match |
| `verify.max_abs_prob_diff` | 7.0e-09 | 6.9e-09 | — | consistent (both ≈ 0) |
| `tpm2.auc` | 0.601 | 0.601 | 0.619 | match (to reported precision) |
| `tpm2.balanced_accuracy` | 0.502 | 0.502 | — | match (to reported precision) |
| `tpm2.log_loss` | 0.679 | 0.679 | — | match (to reported precision) |
| `baseline.balanced_accuracy` | 0.500 | 0.500 | — | match (to reported precision) |
| `baseline.log_loss` | 0.683 | 0.683 | — | match (to reported precision) |
| `tpm2.p_wald` | 0.076 | 0.076 | — | match (to reported precision) |
| `tpm2.p_lrt` | 0.055 | 0.055 | — | match (to reported precision) |
| `tpm2.roc_repeat1_pooled_auc` | 0.591 | 0.591 | — | match (to reported precision) |
| `subgroup.EBV-positive.n` | 85 | 85 | — | match |
| `subgroup.EBV-positive.events` | 44 | 44 | — | match |
| `subgroup.EBV-positive.auc` | 0.547 | 0.531 | 0.573 | DIFFERS (-0.016) |
| `subgroup.EBV-negative.n` | 81 | 81 | — | match |
| `subgroup.EBV-negative.events` | 27 | 27 | — | match |
| `subgroup.EBV-negative.auc` | 0.507 | 0.505 | 0.563 | DIFFERS (-0.002) |
| `subgroup.Pediatric.n` | 97 | 97 | — | match |
| `subgroup.Pediatric.events` | 53 | 53 | — | match |
| `subgroup.Pediatric.auc` | 0.530 | 0.548 | 0.589 | DIFFERS (+0.018) |
| `subgroup.Adult.n` | 68 | 68 | — | match |
| `subgroup.Adult.events` | 17 | 17 | — | match |
| `subgroup.Adult.auc` | 0.508 | 0.507 | 0.556 | match (to reported precision) |
| `subgroup.age_unknown.n` | 1 | 1 | — | match |
| `interaction.ebv.p` | 0.446 | 0.446 | — | match (to reported precision) |
| `interaction.age_category.p` | 0.653 | 0.653 | — | match (to reported precision) |

## Notes

- Endpoint: y=1 if PFS_STATUS='1:Progression' and PFS_MONTHS ≤ 12; y=0 if PFS_MONTHS ≥ 12 without progression by month 12. 11 of the y=0 patients progressed after month 12. Excluded: 12 with missing PFS data, 31 censored before 12 months.
- CV: RepeatedStratifiedKFold(n_splits=5, n_repeats=10, random_state=20261115); TPM2 standardised within training folds.
- Interaction p-values are likelihood-ratio tests (1 df) of the TPM2×group product term; Wald p-values (EBV 0.471, age category 0.658) are in results.json.
- Direction: TPM2 slope -0.317 per z-score unit (OR 0.73, 95% CI 0.51–1.03): higher TPM2 went with lower recorded 12-month progression in this cohort. The report does not state the direction.
- Report Figure 1: converged mean log-likelihood -0.6716; after 3000 fixed steps the α-sweep reaches α=0.001: -0.6771, α=0.01: -0.6716, α=0.1: -0.6716, α=0.3: -0.6716 (see fig01).
- Comparison models (age, clinical, combined) and leave-one-centre-out are extensions: the updated report gives no numbers for them. Pooled LOCO AUCs: TPM2 only 0.343; Age only 0.395; Clinical (age, sex, EBV, HIV) 0.396; TPM2 + clinical 0.388.
